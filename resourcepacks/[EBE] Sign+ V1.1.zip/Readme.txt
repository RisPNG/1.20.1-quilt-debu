MAIN PURPOSE:
  This pack is meant to be used as a Minecraft Resource Pack that modifies the in-game content visually.

INFORMATION...
  This pack is usable with any Resource Packs, but the "Enhanced Block Entities" mod must be installed.

VERSIONS...
  1.14 to 1.20.x

 **IF THERE'S AN INCOMPATIBLE WARNING, JUST IGNORE IT — IT WILL BE FINE**


HOW TO INSTALL...
  1. Launch the game
  2. On the Game Main Menu, Go to 'Options... -> Resource Packs...'
  3. Click 'Open Pack Folder'
  4. Drag the Resource Packs file into the folder
  5. Now, In Resource Packs Menu, Apply the resource pack.
  6. Enjoy the pack...

 **MAKE SURE THAT THIS RESOURCE PACK IS ON TOP OF THE OTHER PACK**

TERMS OF USE:
This creation is protected under 'NaiNonTheN00b1's Terms of Use [Class II].'

More Information about NaiNonTheN00b1's Terms of Use:
https://docs.google.com/document/d/1lJohDcwPjgQN1oY7005tKDXMN-SMPk0Boo5u2m3VrpA/edit?usp=sharing

**BY DOWNLOADING, YOU'VE ALREADY AGREED WITH NAINONTHEN00B1'S TERMS OF USE. NO EXCUSES.**